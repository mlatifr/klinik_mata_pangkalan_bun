package com.example.klinik_mata_pangkalan_bun

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
